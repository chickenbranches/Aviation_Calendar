package com.chickenbranches.aviationcalendar;

import android.content.Context;

public class CheckVersion {
    Context context;

    public CheckVersion(Context context2) {
        this.context = context2;
    }
}
